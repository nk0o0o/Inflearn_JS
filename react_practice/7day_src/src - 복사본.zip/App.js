import { useState } from "react";
import Products from "./Products";

function App() {
 const [showProducts, setShowProducts]=useState(true) 
  return (
    <div className="App">
      <h1>UseEffect</h1>
      {showProducts&&<Products/>}{/* 불러온 값있어?? */}
      <button onClick={()=>{setShowProducts(!showProducts)}}>Toggle</button>      
    </div>
  );
}

export default App;
