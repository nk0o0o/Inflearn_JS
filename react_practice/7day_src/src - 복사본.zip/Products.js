import React, { useEffect, useState } from 'react'

export default function Products() {
    //값받을 저장소
    const [products, setProducts] = useState([]);
    const [checked, setChecked] = useState(false);
    //값 불러오기
    useEffect(() => {
        fetch(`data/${checked?'sale_':''}products.json`)//네트워크 접근
        .then(res => res.json())//콜백 데이터를 res변수에 담기, 한줄함수
        .then(data => {
            console.log('네트워크에서 data를 받아옴')
            setProducts(data)//이렇게만하고 []없으면 끝도없이 저장함(index.js에서 stricMode 때문에계속 돌고돎)
        })//json()한 데이터 data변수에 담기
        return () => {
            console.log('클리어 하는 공간');
        };
    },[checked])//dependancy: 값수정 및 삭제는 react가 할거니깐, 넌 가만히 있어 []빈값이면 dom읽고나서 한번만 읽음 /변경되면 변경된값 읽어들임
    //겁네중요✨✨✨✨
    const handleChange=()=>{
        setChecked(prev =>!prev)
        console.log(checked)
    }
    return (
        <div>
            <div>
               <input id='checkBox' type='checkbox' value={checked}
               onChange={handleChange}/>
               <label htmlFor='checkBox'>Show Sale</label>
            </div>
          <ul>
            {products.map(product=>(
                <li key={product.id}>
                    <h3>{product.name}</h3>
                    <p>{product.price}</p>
                </li>
            ))}
          </ul>
        </div>
    );
}
