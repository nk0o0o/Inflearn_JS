<template>
  <main class="page_home">

    메인화면  </main>
</template>

<script>
export default {
  name: "Home",
  setup () {
    return {}
  }
}
</script>

<style scoped>
/* .page_home{
  height: calc(100vh - 48px);
} */
</style>