<template>
  <main class="page_error">
    페이지를 찾을 수 없습니다
  </main>
</template>

<script>
export default {
  setup () {
    

    return {}
  }
}
</script>

<style lang="scss" scoped>

</style>